from .crosswork_companion import cli
def run():
    cli()